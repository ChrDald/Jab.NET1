**Project Description**
It's a screen ruler for Windows.

![](Home_ruler.png)